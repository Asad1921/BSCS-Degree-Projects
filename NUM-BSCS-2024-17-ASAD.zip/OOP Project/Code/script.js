// Global variables
let currentStudent = null;
let currentExaminer = null;
let currentQuestions = [];
let currentQuestionIndex = 0;
let selectedAnswers = new Map();
let paragraphAnswers = new Map();
let timerInterval = null;
let timeLeft = 40 * 60;
let examDuration = 40;
let categories = [];

// Page Navigation
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');
}

// Load Categories
async function loadCategories() {
    try {
        const response = await fetch('/api/categories');
        const data = await response.json();
        categories = data.categories;
        
        // Populate category selectors
        const categorySelects = document.querySelectorAll('#new-student-category, #question-category');
        categorySelects.forEach(select => {
            select.innerHTML = '<option value="">Select Category</option>';
            categories.forEach((cat, index) => {
                const option = document.createElement('option');
                option.value = index;
                option.textContent = cat;
                select.appendChild(option);
            });
        });
        
        return categories;
    } catch (error) {
        console.error('Error loading categories:', error);
        return [];
    }
}

// ============ HEAD ADMIN FUNCTIONS ============
async function headAdminLogin() {
    const email = document.getElementById('head-admin-email').value;
    const password = document.getElementById('head-admin-password').value;
    
    try {
        const response = await fetch('/api/head-admin-login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await response.json();
        
        if (data.success) {
            await loadCategories();
            loadHeadAdminData();
            showPage('head-admin-panel');
        } else {
            document.getElementById('head-admin-error').textContent = data.error || "Invalid credentials";
            document.getElementById('head-admin-error').classList.add('active');
        }
    } catch (error) {
        console.error('Login error:', error);
        document.getElementById('head-admin-error').textContent = "Server connection failed";
        document.getElementById('head-admin-error').classList.add('active');
    }
}

async function loadHeadAdminData() {
    await loadCategories();
    loadCategoriesList();
    loadExaminersList();
    loadAllResults();
}

function showAdminSection(section) {
    document.querySelectorAll('.admin-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(`admin-${section}`).classList.add('active');
    document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
    event.target.classList.add('active');
}

function showAddCategoryForm() {
    document.getElementById('add-category-form').style.display = 'block';
}

function hideAddCategoryForm() {
    document.getElementById('add-category-form').style.display = 'none';
}

async function addCategory() {
    const name = document.getElementById('new-category-name').value.trim();
    if (!name) return alert("Please enter category name");
    
    try {
        const response = await fetch('/api/add-category', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        const data = await response.json();
        
        if (data.success) {
            await loadCategories();
            loadCategoriesList();
            hideAddCategoryForm();
            document.getElementById('new-category-name').value = '';
        } else {
            alert(data.error || "Failed to add category");
        }
    } catch (error) {
        alert("Server error: " + error.message);
    }
}

function loadCategoriesList() {
    const tbody = document.getElementById('categories-tbody');
    tbody.innerHTML = '';
    
    categories.forEach((cat, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${index}</td>
            <td>${cat}</td>
        `;
        tbody.appendChild(tr);
    });
}

function showAddExaminerForm() {
    document.getElementById('add-examiner-form').style.display = 'block';
}

function hideAddExaminerForm() {
    document.getElementById('add-examiner-form').style.display = 'none';
}

async function addExaminer() {
    const name = document.getElementById('new-examiner-name').value.trim();
    const email = document.getElementById('new-examiner-email').value.trim();
    const password = document.getElementById('new-examiner-password').value;
    const categoriesStr = document.getElementById('new-examiner-categories').value.trim();
    
    if (!name || !email || !password) {
        return alert("Please fill all required fields");
    }
    
    try {
        const response = await fetch('/api/add-examiner', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password, allowedCategories: categoriesStr })
        });
        const data = await response.json();
        
        if (data.success) {
            loadExaminersList();
            hideAddExaminerForm();
            // Clear form
            document.getElementById('new-examiner-name').value = '';
            document.getElementById('new-examiner-email').value = '';
            document.getElementById('new-examiner-password').value = '';
            document.getElementById('new-examiner-categories').value = '';
            
            alert(`Examiner added successfully! ID: ${data.examiner.id}`);
        } else {
            alert(data.error || "Failed to add examiner");
        }
    } catch (error) {
        alert("Server error: " + error.message);
    }
}

async function loadExaminersList() {
    try {
        const response = await fetch('/api/examiners');
        const data = await response.json();
        
        const tbody = document.getElementById('examiners-tbody');
        tbody.innerHTML = '';
        
        data.examiners.forEach(examiner => {
            const tr = document.createElement('tr');
            const categoryNames = examiner.allowedCategories.map(cat => categories[cat] || cat).join(', ');
            
            tr.innerHTML = `
                <td>${examiner.id}</td>
                <td>${examiner.name}</td>
                <td>${examiner.email}</td>
                <td>${examiner.active ? 'Active' : 'Inactive'}</td>
                <td>${categoryNames}</td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading examiners:', error);
    }
}

async function loadAllResults() {
    try {
        const response = await fetch('/api/all-results');
        const data = await response.json();
        
        const tbody = document.getElementById('all-results-tbody');
        tbody.innerHTML = '';
        
        data.results.forEach(result => {
            const tr = document.createElement('tr');
            const status = result.mcqMarks >= 70 ? 'Pass' : 'Fail';
            
            tr.innerHTML = `
                <td>${result.examiner}</td>
                <td>${result.name}</td>
                <td>${result.category}</td>
                <td>${result.mcqMarks}%</td>
                <td>${result.paragraphMarks}</td>
                <td>${result.date}</td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading all results:', error);
    }
}

// ============ EXAMINER FUNCTIONS ============
async function examinerLogin() {
    const email = document.getElementById('examiner-email').value;
    const password = document.getElementById('examiner-password').value;
    const examinerId = document.getElementById('examiner-id').value;
    
    try {
        const response = await fetch('/api/examiner-login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, examinerId })
        });
        const data = await response.json();
        
        if (data.success) {
            currentExaminer = data.examiner;
            document.getElementById('examiner-name').textContent = currentExaminer.name;
            
            await loadCategories();
            loadExaminerData();
            showPage('examiner-panel');
        } else {
            document.getElementById('examiner-error').textContent = data.error || "Invalid credentials";
            document.getElementById('examiner-error').classList.add('active');
        }
    } catch (error) {
        console.error('Examiner login error:', error);
        document.getElementById('examiner-error').textContent = "Server connection failed";
        document.getElementById('examiner-error').classList.add('active');
    }
}

function showExaminerSection(section) {
    document.querySelectorAll('.admin-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(`examiner-${section}`).classList.add('active');
    document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
    event.target.classList.add('active');
    
    if (section === 'students') loadExaminerStudents();
    if (section === 'questions') loadExaminerQuestions();
    if (section === 'results') loadExaminerResults();
    if (section === 'settings') loadExaminerSettings();
}

async function loadExaminerData() {
    await loadCategories();
    loadExaminerStudents();
    loadExaminerSettings();
}

function showAddStudentForm() {
    document.getElementById('add-student-form').style.display = 'block';
}

function hideAddStudentForm() {
    document.getElementById('add-student-form').style.display = 'none';
}

async function addStudent() {
    const name = document.getElementById('new-student-name').value.trim();
    const email = document.getElementById('new-student-email').value.trim();
    const category = document.getElementById('new-student-category').value;
    
    if (!name || !email || category === '') {
        return alert("Please fill all fields");
    }
    
    try {
        const response = await fetch('/api/add-student', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                examinerId: currentExaminer.id,
                name, 
                email, 
                category: parseInt(category)
            })
        });
        const data = await response.json();
        
        if (data.success) {
            loadExaminerStudents();
            hideAddStudentForm();
            
            // Clear form
            document.getElementById('new-student-name').value = '';
            document.getElementById('new-student-email').value = '';
            document.getElementById('new-student-category').value = '';
            
            alert(`Student added successfully!\nID1: ${data.student.id1}\nID2: ${data.student.id2}`);
        } else {
            alert(data.error || "Failed to add student");
        }
    } catch (error) {
        alert("Server error: " + error.message);
    }
}

async function loadExaminerStudents() {
    try {
        const response = await fetch('/api/examiner-students', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ examinerId: currentExaminer.id })
        });
        const data = await response.json();
        
        const tbody = document.getElementById('my-students-tbody');
        tbody.innerHTML = '';
        
        data.students.forEach(student => {
            const tr = document.createElement('tr');
            const used1 = student.used1 ? '<span class="badge used">Used</span>' : '';
            const used2 = student.used2 ? '<span class="badge used">Used</span>' : '';
            
            tr.innerHTML = `
                <td>${student.name}</td>
                <td>${student.email}</td>
                <td>${student.category}</td>
                <td>${student.id1} ${used1}</td>
                <td>${student.id2} ${used2}</td>
                <td>${student.used1 && student.used2 ? 'Both Used' : 'Active'}</td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading examiner students:', error);
    }
}

async function loadExaminerQuestions() {
    const category = document.getElementById('question-category').value;
    if (category === '') return;
    
    try {
        const response = await fetch('/api/examiner-questions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                examinerId: currentExaminer.id,
                category: parseInt(category)
            })
        });
        const data = await response.json();
        
        document.getElementById('current-duration').textContent = data.duration;
        
        const questionsList = document.getElementById('questions-list');
        questionsList.innerHTML = '';
        
        if (data.questions.length === 0) {
            questionsList.innerHTML = '<p>No questions found for this category.</p>';
            return;
        }
        
        data.questions.forEach((q, index) => {
            const div = document.createElement('div');
            div.className = 'question-item';
            
            let content = `
                <h4>Q${index + 1}: ${q.text}</h4>
                <div class="question-meta">
                    <span class="badge ${q.type === 0 ? 'mcq' : 'paragraph'}">
                        ${q.type === 0 ? 'MCQ' : 'Paragraph'}
                    </span>
                    <span>Duration: ${q.durationMinutes > 0 ? q.durationMinutes + 'min' : 'Default'}</span>
                </div>
            `;
            
            if (q.type === 0) {
                content += `<div class="question-options">`;
                q.options.forEach((opt, i) => {
                    const correct = i === q.correct ? 'correct' : '';
                    content += `<div class="${correct}">${String.fromCharCode(65 + i)}: ${opt}</div>`;
                });
                content += `</div>`;
            }
            
            div.innerHTML = content;
            questionsList.appendChild(div);
        });
    } catch (error) {
        console.error('Error loading examiner questions:', error);
    }
}

function showAddQuestionForm() {
    const category = document.getElementById('question-category').value;
    if (category === '') {
        alert("Please select a category first");
        return;
    }
    document.getElementById('add-question-form').style.display = 'block';
}

function hideAddQuestionForm() {
    document.getElementById('add-question-form').style.display = 'none';
}

function toggleQuestionOptions() {
    const type = document.getElementById('new-question-type').value;
    document.getElementById('mcq-options').style.display = type === '0' ? 'block' : 'none';
}

async function addQuestion() {
    const category = document.getElementById('question-category').value;
    const type = parseInt(document.getElementById('new-question-type').value);
    const text = document.getElementById('new-question-text').value.trim();
    const duration = parseInt(document.getElementById('new-question-duration').value);
    
    if (category === '' || !text) {
        alert("Please fill all required fields");
        return;
    }
    
    if (type === 0) {
        const options = [];
        for (let i = 0; i < 4; i++) {
            const opt = document.getElementById(`new-option-${i}`).value.trim();
            if (!opt) {
                alert(`Please fill option ${i + 1}`);
                return;
            }
            options.push(opt);
        }
        const correct = parseInt(document.getElementById('new-question-correct').value);
        
        try {
            const response = await fetch('/api/add-question', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    examinerId: currentExaminer.id,
                    category: parseInt(category),
                    type,
                    text,
                    "options[0]": options[0],
                    "options[1]": options[1],
                    "options[2]": options[2],
                    "options[3]": options[3],
                    correct,
                    durationMinutes: duration
                })
            });
            
            const data = await response.json();
            if (data.success) {
                loadExaminerQuestions();
                hideAddQuestionForm();
                // Clear form
                document.getElementById('new-question-text').value = '';
                for (let i = 0; i < 4; i++) {
                    document.getElementById(`new-option-${i}`).value = '';
                }
                alert("Question added successfully!");
            } else {
                alert(data.error || "Failed to add question");
            }
        } catch (error) {
            alert("Server error: " + error.message);
        }
    } else {
        // Paragraph question
        try {
            const response = await fetch('/api/add-question', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    examinerId: currentExaminer.id,
                    category: parseInt(category),
                    type,
                    text,
                    durationMinutes: duration
                })
            });
            
            const data = await response.json();
            if (data.success) {
                loadExaminerQuestions();
                hideAddQuestionForm();
                document.getElementById('new-question-text').value = '';
                alert("Paragraph question added successfully!");
            } else {
                alert(data.error || "Failed to add question");
            }
        } catch (error) {
            alert("Server error: " + error.message);
        }
    }
}

async function loadDefaultQuestions() {
    const category = document.getElementById('question-category').value;
    if (category === '') {
        alert("Please select a category first");
        return;
    }
    
    if (!confirm("Load default questions for this category? This will replace existing questions.")) {
        return;
    }
    
    try {
        const response = await fetch('/api/load-default-questions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                examinerId: currentExaminer.id,
                category: parseInt(category)
            })
        });
        
        const data = await response.json();
        if (data.success) {
            loadExaminerQuestions();
            alert("Default questions loaded successfully!");
        } else {
            alert(data.error || "Failed to load default questions");
        }
    } catch (error) {
        alert("Server error: " + error.message);
    }
}

function showSetDurationForm() {
    document.getElementById('set-duration-form').style.display = 'block';
}

function hideSetDurationForm() {
    document.getElementById('set-duration-form').style.display = 'none';
}

async function setDuration() {
    const category = document.getElementById('question-category').value;
    const duration = parseInt(document.getElementById('new-duration').value);
    
    if (category === '' || duration < 1) {
        alert("Please enter a valid duration (minimum 1 minute)");
        return;
    }
    
    try {
        const response = await fetch('/api/set-duration', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                examinerId: currentExaminer.id,
                category: parseInt(category),
                duration
            })
        });
        
        const data = await response.json();
        if (data.success) {
            loadExaminerQuestions();
            hideSetDurationForm();
            alert("Duration updated successfully!");
        } else {
            alert(data.error || "Failed to update duration");
        }
    } catch (error) {
        alert("Server error: " + error.message);
    }
}

async function loadExaminerResults() {
    try {
        const response = await fetch('/api/examiner-results', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ examinerId: currentExaminer.id })
        });
        const data = await response.json();
        
        const tbody = document.getElementById('examiner-results-tbody');
        tbody.innerHTML = '';
        
        data.results.forEach(result => {
            const tr = document.createElement('tr');
            const status = result.mcqMarks >= 70 ? 'Pass' : 'Fail';
            const statusClass = result.mcqMarks >= 70 ? 'pass' : 'fail';
            
            tr.innerHTML = `
                <td>${result.name}</td>
                <td>${result.category}</td>
                <td><span class="score ${statusClass}">${result.mcqMarks}%</span></td>
                <td>${result.paragraphCount}</td>
                <td>${result.date}</td>
                <td><span class="badge ${statusClass}">${status}</span></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading examiner results:', error);
    }
}

function loadExaminerSettings() {
    const listDiv = document.getElementById('allowed-categories-list');
    listDiv.innerHTML = '';
    
    if (!currentExaminer || !currentExaminer.allowedCategories) {
        listDiv.innerHTML = '<p>No categories assigned.</p>';
        return;
    }
    
    const ul = document.createElement('ul');
    ul.className = 'category-list';
    
    currentExaminer.allowedCategories.forEach(catIndex => {
        const li = document.createElement('li');
        li.textContent = categories[catIndex] || `Category ${catIndex}`;
        ul.appendChild(li);
    });
    
    listDiv.appendChild(ul);
}

async function exportStudentIDs() {
    try {
        const response = await fetch('/api/examiner-students', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ examinerId: currentExaminer.id })
        });
        const data = await response.json();
        
        let csv = 'Name,Email,Category,ID1,ID2,Used1,Used2\n';
        data.students.forEach(student => {
            csv += `"${student.name}","${student.email}","${student.category}",${student.id1},${student.id2},${student.used1},${student.used2}\n`;
        });
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `students_${currentExaminer.id}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        alert("Student IDs exported successfully!");
    } catch (error) {
        console.error('Error exporting student IDs:', error);
        alert("Failed to export student IDs");
    }
}

async function exportResults() {
    try {
        const response = await fetch('/api/examiner-results', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ examinerId: currentExaminer.id })
        });
        const data = await response.json();
        
        let csv = 'Name,Email,Category,MCQ Score,Paragraph Count,Date\n';
        data.results.forEach(result => {
            csv += `"${result.name}","${result.email}","${result.category}",${result.mcqMarks},${result.paragraphCount},"${result.date}"\n`;
        });
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `results_${currentExaminer.id}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        alert("Results exported successfully!");
    } catch (error) {
        console.error('Error exporting results:', error);
        alert("Failed to export results");
    }
}

// ============ STUDENT FUNCTIONS ============
async function studentLogin() {
    const id = document.getElementById('student-id').value.trim();
    const errorEl = document.getElementById('student-error');
    
    if (!id) {
        errorEl.textContent = "Please enter your Test ID";
        errorEl.classList.add('active');
        return;
    }
    errorEl.classList.remove('active');
    
    try {
        const response = await fetch('/api/student-login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });
        const data = await response.json();
        
        if (data.success) {
            currentStudent = data.student;
            currentStudent.id = id;
            
            document.getElementById('regulations-name').textContent = currentStudent.name;
            document.getElementById('regulations-category').textContent = currentStudent.category;
            
            showPage('regulations-page');
        } else {
            errorEl.textContent = data.error || "Invalid or already used ID";
            errorEl.classList.add('active');
        }
    } catch (error) {
        errorEl.textContent = "Server connection failed. Is the server running?";
        errorEl.classList.add('active');
    }
}

async function startExam() {
    console.log("DEBUG: startExam() called");
    console.log("Current Student:", currentStudent);
    
    if (!currentStudent || !currentStudent.id) {
        alert("Student not properly logged in. Please login again.");
        showPage('student-login');
        return;
    }
    
    try {
        console.log("DEBUG: Calling API with studentId:", currentStudent.id);
        
        // Add timeout to prevent hanging
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);
        
        const response = await fetch('/api/get-exam-questions', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ 
                studentId: currentStudent.id,
                examinerId: currentStudent.examinerId,
                category: currentStudent.categoryIndex
            }),
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        console.log("DEBUG: Response status:", response.status);
        console.log("DEBUG: Response headers:", response.headers);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error("DEBUG: API Error response:", errorText);
            
            if (response.status === 404) {
                alert("Student or questions not found. Please contact examiner.");
            } else {
                alert(`Server error (${response.status}): ${errorText}`);
            }
            return;
        }
        
        const data = await response.json();
        console.log("DEBUG: Parsed response data:", data);
        
        // Check if questions exist
        if (!data.questions) {
            console.error("DEBUG: No 'questions' property in response");
            alert("Error: Questions data format incorrect!");
            return;
        }
        
        if (!Array.isArray(data.questions)) {
            console.error("DEBUG: Questions is not an array:", typeof data.questions);
            alert("Error: Questions data is not in correct format!");
            return;
        }
        
        if (data.questions.length === 0) {
            console.warn("DEBUG: Questions array is empty");
            alert("No questions available for this exam!\n\nPlease ask examiner to:\n1. Go to Questions section\n2. Select your category\n3. Click 'Load Default' button");
            showPage('regulations-page');
            return;
        }
        
        console.log(`DEBUG: Successfully loaded ${data.questions.length} questions`);
        
        // Store questions and start exam
        currentQuestions = data.questions;
        examDuration = data.duration || 40;
        selectedAnswers.clear();
        paragraphAnswers.clear();
        currentQuestionIndex = 0;
        
        // Create test page if not exists
        createTestPage();
        
        // Update UI
        if (document.getElementById('test-student-name')) {
            document.getElementById('test-student-name').textContent = currentStudent.name;
        }
        if (document.getElementById('test-category')) {
            document.getElementById('test-category').textContent = currentStudent.category;
        }
        
        showPage('test-page');
        startTimer();
        showQuestion();
        enableAntiCheat();
        
    } catch (error) {
        console.error('DEBUG: Error in startExam:', error);
        
        if (error.name === 'AbortError') {
            alert("Request timed out. Please check:\n1. Server is running\n2. Internet connection\n3. Try again");
        } else if (error.name === 'TypeError' && error.message.includes('fetch')) {
            alert("Cannot connect to server. Please:\n1. Ensure server is running on port 8080\n2. Restart the server\n3. Refresh the page");
        } else {
            alert(`Failed to load exam: ${error.message}\n\nTroubleshooting:\n1. Check server console for errors\n2. Verify student exists in system\n3. Contact administrator`);
        }
    }
}
function createTestPage() {
    // Remove existing test page if any
    const existingPage = document.getElementById('test-page');
    if (existingPage) existingPage.remove();
    
    // Create test page HTML
    const testPage = document.createElement('div');
    testPage.id = 'test-page';
    testPage.className = 'page';
    testPage.innerHTML = `
        <div class="container">
            <div class="card">
                <div class="test-header">
                    <div>
                        <h2>Online Exam</h2>
                        <p><strong>Student:</strong> <span id="test-student-name"></span></p>
                        <p><strong>Category:</strong> <span id="test-category"></span></p>
                    </div>
                    <div class="timer-display">
                        <div class="timer-label">Time Remaining:</div>
                        <div class="timer" id="timer">40:00</div>
                    </div>
                </div>
                
                <div class="test-progress">
                    <div class="progress-bar">
                        <div class="progress" id="progress"></div>
                    </div>
                    <div class="progress-text" id="progress-text">0%</div>
                </div>
                
                <div class="question-container">
                    <div class="question-header">
                        <span id="question-number">Question 1/20</span>
                        <span id="question-type" class="question-type">MCQ Question</span>
                    </div>
                    
                    <div class="question-text" id="question-text">
                        Question text will appear here...
                    </div>
                    
                    <div id="options" class="options-container">
                        <!-- MCQ options will be inserted here -->
                    </div>
                    
                    <div id="paragraph-answer" class="paragraph-container" style="display:none;">
                        <textarea id="paragraph-text" placeholder="Type your answer here..." rows="8"></textarea>
                    </div>
                    
                    <div class="test-controls">
                        <button class="btn btn-secondary" onclick="skipQuestion()">Skip</button>
                        <button class="btn btn-primary" onclick="nextQuestion()">Next Question</button>
                        <button class="btn btn-danger" onclick="endTest()">Submit Exam</button>
                    </div>
                </div>
                
                <div class="test-warning">
                    ⚠️ Warning: Do not switch tabs or close browser. All actions are being monitored.
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(testPage);
}

function showQuestion() {
    console.log("DEBUG: showQuestion() called");
    console.log("Current index:", currentQuestionIndex, "Total questions:", currentQuestions.length);
    console.log("Questions array:", currentQuestions);
    
    // Check if we have questions loaded
    if (!currentQuestions || currentQuestions.length === 0) {
        console.error("DEBUG: No questions loaded! currentQuestions is empty");
        alert("No questions available. The exam has no questions. Please contact examiner.");
        showPage('regulations-page');
        return;
    }
    
    // Check if currentQuestionIndex is valid
    if (currentQuestionIndex < 0 || currentQuestionIndex >= currentQuestions.length) {
        console.error("DEBUG: Invalid question index:", currentQuestionIndex, "out of", currentQuestions.length);
        // Reset to first question if invalid
        currentQuestionIndex = 0;
    }
    
    const q = currentQuestions[currentQuestionIndex];
    console.log("DEBUG: Showing question", currentQuestionIndex + 1, "Type:", q.type);
    console.log("Question object:", q);
    
    // Update question number display
    document.getElementById('question-number').textContent = 
        `Question ${currentQuestionIndex + 1}/${currentQuestions.length}`;
    
    document.getElementById('question-type').textContent = 
        q.type === 0 ? 'MCQ Question' : 'Paragraph Question';
    
    document.getElementById('question-text').textContent = q.text || "Question text not available";
    
    const optionsDiv = document.getElementById('options');
    const paragraphDiv = document.getElementById('paragraph-answer');
    
    if (q.type === 0) {
        console.log("DEBUG: Displaying MCQ options");
        optionsDiv.style.display = 'block';
        paragraphDiv.style.display = 'none';
        
        // Clear previous options
        optionsDiv.innerHTML = '';
        
        // Check if options exist
        if (!q.options || q.options.length === 0) {
            console.error("DEBUG: No options available for MCQ question");
            optionsDiv.innerHTML = '<p style="color: red;">Error: No options available for this question</p>';
        } else {
            // Add new options
            q.options.forEach((opt, i) => {
                const div = document.createElement('div');
                div.className = 'option';
                
                // Check if this option was previously selected
                if (selectedAnswers.get(currentQuestionIndex) === i) {
                    div.classList.add('selected');
                }
                
                div.innerHTML = `
                    <span class="option-letter">${String.fromCharCode(65 + i)}</span>
                    <span>${opt || `Option ${i+1}`}</span>
                `;
                
                div.onclick = () => {
                    console.log("DEBUG: Selected option", i, "for question", currentQuestionIndex);
                    selectedAnswers.set(currentQuestionIndex, i);
                    document.querySelectorAll('#options .option').forEach(o => o.classList.remove('selected'));
                    div.classList.add('selected');
                    updateProgress();
                };
                
                optionsDiv.appendChild(div);
            });
        }
    } else {
        console.log("DEBUG: Displaying paragraph answer box");
        optionsDiv.style.display = 'none';
        paragraphDiv.style.display = 'block';
        
        const textarea = document.getElementById('paragraph-text');
        textarea.value = paragraphAnswers.get(currentQuestionIndex) || '';
        
        textarea.oninput = () => {
            paragraphAnswers.set(currentQuestionIndex, textarea.value);
            updateProgress();
        };
    }
    
    updateProgress();
}
function updateProgress() {
    if (currentQuestions.length === 0) return;
    
    let answered = 0;
    
    // Count answered MCQ questions
    selectedAnswers.forEach((answer, index) => {
        if (index < currentQuestions.length) {
            answered++;
        }
    });
    
    // Count answered paragraph questions (non-empty)
    paragraphAnswers.forEach((answer, index) => {
        if (index < currentQuestions.length && answer && answer.trim().length > 0) {
            // Check if we haven't already counted this question
            if (!selectedAnswers.has(index)) {
                answered++;
            }
        }
    });
    
    const percent = (answered / currentQuestions.length) * 100;
    
    const progressBar = document.getElementById('progress');
    const progressText = document.getElementById('progress-text');
    
    if (progressBar) {
        progressBar.style.width = percent + '%';
    }
    
    if (progressText) {
        progressText.textContent = Math.round(percent) + '%';
    }
    
    console.log("DEBUG: Progress updated -", answered, "answered out of", currentQuestions.length, "(", percent, "%)");
}
function nextQuestion() {
    console.log("DEBUG: nextQuestion() called");
    console.log("Current index:", currentQuestionIndex, "Total:", currentQuestions.length);
    
    if (currentQuestions.length === 0) {
        console.error("DEBUG: No questions to navigate");
        return;
    }
    
    if (currentQuestionIndex < currentQuestions.length - 1) {
        currentQuestionIndex++;
        console.log("DEBUG: Moving to question", currentQuestionIndex + 1);
        showQuestion();
    } else {
        console.log("DEBUG: Last question reached, asking for confirmation");
        const confirmSubmit = confirm("This is the last question. Submit exam now?");
        if (confirmSubmit) {
            endTest();
        }
    }
}

function skipQuestion() {
    console.log("DEBUG: skipQuestion() called");
    
    if (currentQuestions.length === 0) {
        console.error("DEBUG: No questions to skip");
        return;
    }
    
    // Mark as unanswered
    if (currentQuestions[currentQuestionIndex].type === 0) {
        selectedAnswers.delete(currentQuestionIndex);
    } else {
        paragraphAnswers.delete(currentQuestionIndex);
    }
    
    // Move to next
    nextQuestion();
}

function updateTimerDisplay() {
    if (timeLeft < 0) timeLeft = 0;
    
    const mins = Math.floor(timeLeft / 60);
    const secs = timeLeft % 60;
    const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    
    const timerElement = document.getElementById('timer');
    if (timerElement) {
        timerElement.textContent = timeStr;
        
        // Change color when time is running low
        if (timeLeft < 300) { // Less than 5 minutes
            timerElement.style.color = '#ff4444';
            timerElement.style.fontWeight = 'bold';
        } else if (timeLeft < 600) { // Less than 10 minutes
            timerElement.style.color = '#ff9900';
        } else {
            timerElement.style.color = '';
            timerElement.style.fontWeight = '';
        }
    }
}

function startTimer() {
    console.log("DEBUG: Starting timer. Exam duration:", examDuration, "minutes");
    
    // Clear any existing timer
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }
    
    // Initialize time
    timeLeft = examDuration * 60;
    
    // Update display immediately
    updateTimerDisplay();
    
    // Start countdown
    timerInterval = setInterval(() => {
        timeLeft--;
        updateTimerDisplay();
        
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            timerInterval = null;
            console.log("DEBUG: Time's up! Auto-submitting...");
            setTimeout(endTest, 1000); // Give 1 second delay before auto-submit
        }
    }, 1000);
    
    console.log("DEBUG: Timer started. timeLeft:", timeLeft, "seconds");
}

async function endTest() {
    clearInterval(timerInterval);
    
    // Prepare answers for submission
    let answersStr = '';
    selectedAnswers.forEach((answer, index) => {
        if (answersStr) answersStr += ';';
        answersStr += `${index}:${answer}`;
    });
    
    let paragraphAnswersStr = '';
    paragraphAnswers.forEach((answer, index) => {
        if (answer?.trim()) {
            if (paragraphAnswersStr) paragraphAnswersStr += '|';
            paragraphAnswersStr += encodeURIComponent(answer);
        }
    });
    
    try {
        const response = await fetch('/api/submit-exam', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                studentId: currentStudent.id,
                answers: answersStr,
                paragraphAnswers: paragraphAnswersStr
            })
        });
        
        const data = await response.json();
        if (data.success) {
            document.getElementById('final-score').textContent = data.result.mcqScore;
            
            const statusEl = document.getElementById('result-status');
            const iconEl = document.getElementById('result-icon');
            const detailsEl = document.getElementById('result-details');
            
            if (data.result.mcqScore >= 70) {
                statusEl.textContent = "Congratulations! You Passed!";
                statusEl.className = "result-status pass";
                iconEl.textContent = "🎉";
            } else {
                statusEl.textContent = "Failed - Better Luck Next Time";
                statusEl.className = "result-status fail";
                iconEl.textContent = "❌";
            }
            
            detailsEl.innerHTML = `
                <p>MCQ Score: ${data.result.mcqScore}%</p>
                <p>Correct: ${data.result.mcqCorrect} out of ${data.result.mcqTotal}</p>
                <p>Total Questions: ${data.result.totalQuestions}</p>
                <p>Paragraph Answers: ${data.result.paragraphCount}</p>
                <p>Paragraph answers will be evaluated by examiner.</p>
            `;
            
            // Download button
            const downloadBtn = document.getElementById('download-result-btn');
            downloadBtn.onclick = () => {
                const content = `
Cygentic Test Center Result
===========================
Name: ${currentStudent.name}
Category: ${currentStudent.category}
MCQ Score: ${data.result.mcqScore}%
Correct Answers: ${data.result.mcqCorrect}/${data.result.mcqTotal}
Total Questions: ${data.result.totalQuestions}
Paragraph Answers: ${data.result.paragraphCount}
Date: ${new Date().toLocaleString()}
                `.trim();
                
                const blob = new Blob([content], { type: 'text/plain' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `result_${currentStudent.id}.txt`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            };
            
            showPage('result-page');
        } else {
            alert("Failed to submit exam: " + data.error);
        }
    } catch (error) {
        console.error('Error submitting exam:', error);
        alert("Failed to submit exam");
    }
}

// ============ PARAGRAPH EVALUATION FUNCTIONS ============

function showExaminerSection(section) {
    document.querySelectorAll('.admin-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(`examiner-${section}`).classList.add('active');
    document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
    event.target.classList.add('active');
    
    if (section === 'students') loadExaminerStudents();
    if (section === 'questions') loadExaminerQuestions();
    if (section === 'results') loadExaminerResults();
    if (section === 'settings') loadExaminerSettings();
    if (section === 'evaluation') loadPendingEvaluations(); // NEW
}

async function loadPendingEvaluations() {
    try {
        const response = await fetch('/api/pending-evaluations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ examinerId: currentExaminer.id })
        });
        
        const data = await response.json();
        const tbody = document.getElementById('pending-evaluations-tbody');
        tbody.innerHTML = '';
        
        if (data.students.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px;">
                        No pending evaluations. All paragraph answers have been evaluated.
                    </td>
                </tr>
            `;
            return;
        }
        
        data.students.forEach(student => {
            const tr = document.createElement('tr');
            const status = student.evaluated ? 
                `<span class="badge evaluated">Evaluated</span>` : 
                `<span class="badge pending">Pending</span>`;
            
            tr.innerHTML = `
                <td>${student.name}</td>
                <td>${student.category}</td>
                <td><span class="score">${student.mcqScore}%</span></td>
                <td>${student.paragraphCount}</td>
                <td>${status}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="openEvaluationForm('${student.id}')">
                        ${student.evaluated ? 'Re-evaluate' : 'Evaluate'}
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading pending evaluations:', error);
        alert("Failed to load pending evaluations");
    }
}

async function openEvaluationForm(studentId) {
    try {
        const response = await fetch('/api/get-paragraph-answers', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                examinerId: currentExaminer.id,
                studentId: studentId
            })
        });
        
        const data = await response.json();
        
        // Store current evaluation data
        window.currentEvaluation = {
            studentId: studentId,
            mcqScore: data.mcqScore,
            paragraphs: data.paragraphs
        };
        
        // Update UI
        document.getElementById('eval-student-name').textContent = data.studentName;
        document.getElementById('eval-category').textContent = data.category;
        document.getElementById('eval-mcq-score').textContent = data.mcqScore;
        document.getElementById('eval-paragraph-count').textContent = data.totalParagraphs;
        
        // Create paragraph answer inputs
        const container = document.getElementById('paragraph-answers-container');
        container.innerHTML = '';
        
        data.paragraphs.forEach((paragraph, index) => {
            const div = document.createElement('div');
            div.className = 'paragraph-evaluation-item';
            div.innerHTML = `
                <h4>Paragraph Answer ${index + 1}</h4>
                <div class="answer-text">${paragraph.answer || 'No answer provided'}</div>
                <div class="marks-input">
                    <label>Award Marks (0-10):</label>
                    <input type="number" 
                           class="paragraph-mark-input" 
                           data-index="${index}"
                           min="0" 
                           max="10" 
                           value="${paragraph.marks || 0}"
                           oninput="updateMarksSummary()">
                </div>
            `;
            container.appendChild(div);
        });
        
        // Show form
        document.getElementById('evaluation-form-container').style.display = 'block';
        document.getElementById('examiner-evaluation').scrollIntoView();
        
        // Update summary
        updateMarksSummary();
        
    } catch (error) {
        console.error('Error opening evaluation form:', error);
        alert("Failed to load paragraph answers");
    }
}

function updateMarksSummary() {
    if (!window.currentEvaluation) return;
    
    const inputs = document.querySelectorAll('.paragraph-mark-input');
    let totalMarks = 0;
    
    inputs.forEach(input => {
        const mark = parseInt(input.value) || 0;
        totalMarks += mark;
    });
    
    // Update current evaluation
    window.currentEvaluation.totalParagraphMarks = totalMarks;
    
    // Calculate final total score (MCQ + Paragraph marks converted to percentage)
    // Assuming 20 questions total: 10 MCQ (10 marks each) and 10 Paragraph (10 marks each)
    // So total possible marks = 200
    const maxParagraphMarks = inputs.length * 10;
    const maxMCQMarks = 100; // MCQ is already in percentage
    
    // Convert paragraph marks to percentage
    const paragraphPercentage = maxParagraphMarks > 0 ? 
        (totalMarks / maxParagraphMarks) * 100 : 0;
    
    // Calculate weighted final score (50% MCQ, 50% Paragraph)
    const finalScore = Math.round((window.currentEvaluation.mcqScore * 0.5) + (paragraphPercentage * 0.5));
    
    // Update UI
    document.getElementById('total-marks').textContent = totalMarks;
    document.getElementById('final-total-score').textContent = finalScore + '%';
}

async function saveParagraphMarks() {
    if (!window.currentEvaluation) return;
    
    // Collect marks from all inputs
    const inputs = document.querySelectorAll('.paragraph-mark-input');
    const marksArray = [];
    
    inputs.forEach(input => {
        marksArray.push(parseInt(input.value) || 0);
    });
    
    const marksString = marksArray.join(',');
    
    try {
        const response = await fetch('/api/update-paragraph-marks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                examinerId: currentExaminer.id,
                studentId: window.currentEvaluation.studentId,
                marks: marksString
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert("Evaluation saved successfully!");
            closeEvaluationForm();
            loadPendingEvaluations();
            loadExaminerResults(); // Refresh results table
        } else {
            alert("Failed to save evaluation: " + data.error);
        }
    } catch (error) {
        console.error('Error saving paragraph marks:', error);
        alert("Failed to save evaluation");
    }
}

function closeEvaluationForm() {
    document.getElementById('evaluation-form-container').style.display = 'none';
    window.currentEvaluation = null;
}

// Update the results display to show total score
async function loadExaminerResults() {
    try {
        const response = await fetch('/api/examiner-results', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ examinerId: currentExaminer.id })
        });
        const data = await response.json();
        
        const tbody = document.getElementById('examiner-results-tbody');
        tbody.innerHTML = '';
        
        data.results.forEach(result => {
            const tr = document.createElement('tr');
            
            // Calculate total score (MCQ + Paragraph)
            const paragraphMax = result.paragraphCount * 10;
            const paragraphPercentage = paragraphMax > 0 ? 
                (result.paragraphMarks / paragraphMax) * 100 : 0;
            const totalScore = Math.round((result.mcqMarks * 0.5) + (paragraphPercentage * 0.5));
            
            const status = totalScore >= 70 ? 'Pass' : 'Fail';
            const statusClass = totalScore >= 70 ? 'pass' : 'fail';
            
            tr.innerHTML = `
                <td>${result.name}</td>
                <td>${result.category}</td>
                <td><span class="score">${result.mcqMarks}%</span></td>
                <td>${result.paragraphCount}</td>
                <td><span class="score">${result.paragraphMarks} marks</span></td>
                <td><span class="score ${statusClass}">${totalScore}%</span></td>
                <td>${result.date}</td>
                <td><span class="badge ${statusClass}">${status}</span></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error loading examiner results:', error);
    }
}
function enableAntiCheat() {
    const sendAlert = async (type) => {
        try {
            await fetch('/api/proctor-alert', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    studentId: currentStudent.id, 
                    alert: type 
                })
            });
        } catch (error) {
            console.error('Failed to send alert:', error);
        }
    };
    
    // Block Copy
    document.addEventListener('copy', (e) => {
        e.preventDefault();
        sendAlert('copy_attempt');
        alert("Copying is not allowed during the test!");
    });
    
    // Block Right-Click
    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        sendAlert('right_click_attempt');
    });
    
    // Block Developer Tools Shortcuts
    document.addEventListener('keydown', (e) => {
        if (
            e.keyCode === 123 ||
            (e.ctrlKey && e.shiftKey && e.keyCode === 73) ||
            (e.ctrlKey && e.shiftKey && e.keyCode === 74) ||
            (e.ctrlKey && e.keyCode === 85)
        ) {
            e.preventDefault();
            sendAlert('dev_tools_attempt');
            alert("Developer tools are disabled during the test.");
        }
    });
    
    // Detect Tab Switch
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
            sendAlert('tab_switch');
            alert("Tab switch detected! This has been recorded.");
        }
    });
    
    // Detect PrintScreen key
    document.addEventListener('keyup', (e) => {
        if (e.key === 'PrintScreen') {
            sendAlert('print_screen_attempt');
            navigator.clipboard.writeText('');
            alert("Screenshots are not allowed!");
        }
    });
    
    // Prevent text selection
    document.body.style.userSelect = 'none';
    document.body.style.webkitUserSelect = 'none';
    document.body.style.mozUserSelect = 'none';
    document.body.style.msUserSelect = 'none';
}

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', () => {
    console.log("Cygentic Test Center Loaded");
    loadCategories();
});

// Add test page CSS dynamically
const testPageCSS = `
.test-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 30px;
    flex-wrap: wrap;
    gap: 20px;
}

.timer-display {
    background: #2c3e50;
    color: white;
    padding: 15px 25px;
    border-radius: 10px;
    text-align: center;
    min-width: 180px;
}

.timer-label {
    font-size: 14px;
    opacity: 0.9;
    margin-bottom: 5px;
}

.timer {
    font-size: 2.5rem;
    font-weight: bold;
    font-family: monospace;
    letter-spacing: 2px;
}

.test-progress {
    margin: 30px 0;
}

.progress-bar {
    height: 10px;
    background: #e0e0e0;
    border-radius: 5px;
    overflow: hidden;
    margin-bottom: 10px;
}

.progress {
    height: 100%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    width: 0%;
    transition: width 0.3s;
}

.progress-text {
    text-align: center;
    font-weight: bold;
    color: #667eea;
    font-size: 18px;
}

.question-container {
    background: #f8f9fa;
    padding: 30px;
    border-radius: 10px;
    margin: 30px 0;
}

.question-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.question-type {
    background: #667eea;
    color: white;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 600;
}

.question-text {
    font-size: 20px;
    line-height: 1.6;
    color: #2c3e50;
    margin-bottom: 30px;
    padding: 20px;
    background: white;
    border-radius: 8px;
    border-left: 4px solid #667eea;
}

.options-container {
    display: grid;
    gap: 12px;
    margin-bottom: 30px;
}

.option {
    background: white;
    padding: 18px 20px;
    border-radius: 8px;
    cursor: pointer;
    border: 2px solid #e0e0e0;
    display: flex;
    align-items: center;
    transition: all 0.3s;
}

.option:hover {
    border-color: #667eea;
    transform: translateX(5px);
}

.option.selected {
    border-color: #667eea;
    background: #eef2ff;
}

.option-letter {
    background: #667eea;
    color: white;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    font-weight: bold;
    flex-shrink: 0;
}

.paragraph-container textarea {
    width: 100%;
    padding: 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 16px;
    line-height: 1.6;
    margin-bottom: 20px;
    transition: border-color 0.3s;
}

.paragraph-container textarea:focus {
    border-color: #667eea;
    outline: none;
}

.test-controls {
    display: flex;
    justify-content: space-between;
    margin-top: 40px;
    flex-wrap: wrap;
    gap: 15px;
}

.test-warning {
    background: #fff3cd;
    color: #856404;
    padding: 15px;
    border-radius: 8px;
    text-align: center;
    margin-top: 30px;
    border: 1px solid #ffeaa7;
    font-weight: 500;
}
`;

const style = document.createElement('style');
style.textContent = testPageCSS;
document.head.appendChild(style);