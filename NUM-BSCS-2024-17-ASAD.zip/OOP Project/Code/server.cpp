// server.cpp - Cygentic Test Center Web Server (with Examiners, Head Admin, MCQ & Paragraph)
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <map>
#include <algorithm>
#include <cctype>
#include <iomanip>
#ifdef _WIN32
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "ws2_32.lib")
    #define close closesocket
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <unistd.h>
    #include <arpa/inet.h>
#endif
using namespace std;

// ===================== STRUCTS & CLASSES =====================
struct Question {
    int type; // 0=MCQ, 1=Paragraph
    string text;
    string opt[4];
    int correct;
    int durationMinutes;
};

struct Student {
    string name, email, id1, id2;
    bool used1 = false, used2 = false;
    int category;
    string examinerId;
};

struct Result {
    string name, email, id, date;
    int category;
    int mcqMarks;
    int paragraphMarks;
    vector<string> paragraphAnswers;
    string examinerId;
};

struct ExamSetting {
    int duration = 40;
};

struct Examiner {
    string id;
    string name;
    string email;
    string password;
    bool active = true;
    vector<int> allowedCategories;
};

struct ExaminerData {
    string examinerId;
    vector<Question> questionsPerCategory[6];
    ExamSetting settingsPerCategory[6];
    vector<Student> students;
    vector<Result> results;
};

// ===================== GLOBAL DATA =====================
vector<string> categories = {
    "Cyber Security", "Artificial Intelligence", "Graphic Designing",
    "Data Science", "Web Development", "Software Engineering"
};

vector<Examiner> examiners;
vector<ExaminerData> examinerDataList;

const string HEAD_EMAIL = "admin@cygentic.com";
const string HEAD_PASS = "head123#CTA";

map<string, time_t> examTimers;
vector<string> activeExams;
vector<string> alerts;

// ===================== HELPER FUNCTIONS =====================
string generateID() {
    string words[] = {"Alpha","Beta","Cyber","Neo","Zeta","Nova","Sigma","Omega",
                      "Pulse","Vortex","Apex","Zen","Matrix","Quantum","Pixel"};
    return words[rand()%15] + words[rand()%15] + to_string(100 + rand()%900);
}

string generateExaminerID() {
    return "EXM" + to_string(1000 + rand()%9000);
}

string currentTime() {
    time_t n = time(0);
    char buf[100];
    ctime_r(&n, buf);
    string s(buf);
    if(!s.empty() && s.back() == '\n') s.pop_back();
    return s;
}

int safe_stoi(const string& s, int default_value = 0) {
    if (s.empty()) return default_value;
    try {
        return stoi(s);
    } catch (...) {
        return default_value;
    }
}

bool vectorContains(const vector<int>& v, int val) {
    for(auto i : v) if(i == val) return true;
    return false;
}

string escapeJson(const string& s) {
    string result;
    for (char c : s) {
        if (c == '"') result += "\\\"";
        else if (c == '\\') result += "\\\\";
        else if (c == '\n') result += "\\n";
        else if (c == '\r') result += "\\r";
        else if (c == '\t') result += "\\t";
        else result += c;
    }
    return result;
}

string unescapeJson(const string& s) {
    string result;
    for (size_t i = 0; i < s.length(); i++) {
        if (s[i] == '\\' && i+1 < s.length()) {
            i++;
            if (s[i] == 'n') result += '\n';
            else if (s[i] == 'r') result += '\r';
            else if (s[i] == 't') result += '\t';
            else if (s[i] == '"') result += '"';
            else if (s[i] == '\\') result += '\\';
            else result += s[i];
        } else {
            result += s[i];
        }
    }
    return result;
}

map<string, string> parseSimpleJson(const string& input) {
    map<string, string> params;
    string json = input;
    json.erase(remove_if(json.begin(), json.end(), ::isspace), json.end());
    if (json.empty() || json[0] != '{') return params;
    
    size_t pos = 1;
    while (pos < json.length() && json[pos] != '}') {
        if (json[pos] != '"') { pos++; continue; }
        size_t keyStart = pos + 1;
        size_t keyEnd = json.find('"', keyStart);
        if (keyEnd == string::npos) break;
        string key = json.substr(keyStart, keyEnd - keyStart);
        
        size_t colonPos = json.find(':', keyEnd + 1);
        if (colonPos == string::npos) break;
        
        size_t valStart = colonPos + 1;
        if (valStart >= json.length()) break;
        
        if (json[valStart] == '"') {
            valStart++;
            size_t valEnd = json.find('"', valStart);
            if (valEnd == string::npos) break;
            string val = json.substr(valStart, valEnd - valStart);
            params[key] = val;
            pos = valEnd + 1;
        } else {
            size_t valEnd = json.find_first_of(",}", valStart);
            if (valEnd == string::npos) break;
            string val = json.substr(valStart, valEnd - valStart);
            params[key] = val;
            pos = valEnd;
        }
        
        if (pos < json.length() && json[pos] == ',') pos++;
    }
    return params;
}

string httpResponse(int code, const string& body, const string& contentType = "application/json") {
    stringstream ss;
    ss << "HTTP/1.1 " << code << " OK\r\n";
    ss << "Content-Type: " << contentType << "\r\n";
    ss << "Content-Length: " << body.length() << "\r\n";
    ss << "Access-Control-Allow-Origin: *\r\n";
    ss << "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n";
    ss << "Access-Control-Allow-Headers: Content-Type\r\n";
    ss << "Connection: close\r\n\r\n";
    ss << body;
    return ss.str();
}

// ===================== DATA PERSISTENCE =====================
void loadCategories() {
    ifstream f("categories.txt");
    if (!f) return;
    categories.clear();
    string line;
    while (getline(f, line)) {
        if (!line.empty()) categories.push_back(line);
    }
}

void saveCategories() {
    ofstream f("categories.txt");
    if (!f) return;
    for (const auto& cat : categories) f << cat << endl;
}

string getExaminerFileName(const string& exId) {
    return "examiner_" + exId + ".txt";
}

ExaminerData* findExaminerData(const string& exId) {
    for (auto& data : examinerDataList) {
        if (data.examinerId == exId) return &data;
    }
    return nullptr;
}

void saveExaminerData(const string& exId) {
    ExaminerData* d = findExaminerData(exId);
    if (!d) return;
    
    ofstream f(getExaminerFileName(exId));
    if (!f) return;
    
    f << "[QUESTIONS]\n";
    for (int cat = 0; cat < 6; ++cat) {
        for (const auto& q : d->questionsPerCategory[cat]) {
            f << cat << "|" << q.type << "|" << escapeJson(q.text) << "|";
            if (q.type == 0) {
                for (int i = 0; i < 4; ++i) f << escapeJson(q.opt[i]) << "|";
                f << q.correct << "|";
            }
            f << q.durationMinutes << "\n";
        }
    }
    
    f << "[SETTINGS]\n";
    for (int cat = 0; cat < 6; ++cat) {
        f << cat << "|" << d->settingsPerCategory[cat].duration << "\n";
    }
    
    f << "[STUDENTS]\n";
    for (const auto& s : d->students) {
        f << escapeJson(s.name) << "|" << escapeJson(s.email) << "|"
          << s.id1 << "|" << s.id2 << "|"
          << (s.used1 ? "1" : "0") << "|" << (s.used2 ? "1" : "0") << "|"
          << s.category << "|" << s.examinerId << "\n";
    }
    
    f << "[RESULTS]\n";
    for (const auto& r : d->results) {
        f << escapeJson(r.name) << "|" << escapeJson(r.email) << "|"
          << r.id << "|" << escapeJson(r.date) << "|"
          << r.category << "|" << r.mcqMarks << "|" << r.paragraphMarks << "|"
          << r.paragraphAnswers.size();
        for (const auto& ans : r.paragraphAnswers) {
            f << "|" << escapeJson(ans);
        }
        f << "|" << r.examinerId << "\n";
    }
    f.close();
}

void loadExaminerData(const string& exId) {
    ExaminerData nd;
    nd.examinerId = exId;
    
    ifstream f(getExaminerFileName(exId));
    if (!f) {
        examinerDataList.push_back(nd);
        return;
    }
    
    string line, section;
    while (getline(f, line)) {
        if (line.empty()) continue;
        if (line[0] == '[') {
            section = line;
            continue;
        }
        
        stringstream ss(line);
        vector<string> parts;
        string part;
        while (getline(ss, part, '|')) parts.push_back(part);
        
        if (section == "[QUESTIONS]" && parts.size() >= 4) {
            int cat = safe_stoi(parts[0]);
            if (cat < 0 || cat >= 6) continue;
            
            Question q;
            q.type = safe_stoi(parts[1]);
            q.text = unescapeJson(parts[2]);
            
            if (q.type == 0 && parts.size() >= 9) {
                for (int i = 0; i < 4; ++i) q.opt[i] = unescapeJson(parts[3 + i]);
                q.correct = safe_stoi(parts[7]);
                q.durationMinutes = safe_stoi(parts[8]);
            } else if (q.type == 1) {
                q.durationMinutes = safe_stoi(parts.back());
            }
            
            nd.questionsPerCategory[cat].push_back(q);
        }
        else if (section == "[SETTINGS]" && parts.size() == 2) {
            int cat = safe_stoi(parts[0]);
            if (cat >= 0 && cat < 6) {
                nd.settingsPerCategory[cat].duration = safe_stoi(parts[1]);
            }
        }
        else if (section == "[STUDENTS]" && parts.size() >= 8) {
            Student s;
            s.name = unescapeJson(parts[0]);
            s.email = unescapeJson(parts[1]);
            s.id1 = parts[2];
            s.id2 = parts[3];
            s.used1 = (parts[4] == "1");
            s.used2 = (parts[5] == "1");
            s.category = safe_stoi(parts[6]);
            s.examinerId = (parts.size() > 7) ? parts[7] : exId;
            nd.students.push_back(s);
        }
        else if (section == "[RESULTS]" && parts.size() >= 9) {
            Result r;
            r.name = unescapeJson(parts[0]);
            r.email = unescapeJson(parts[1]);
            r.id = parts[2];
            r.date = unescapeJson(parts[3]);
            r.category = safe_stoi(parts[4]);
            r.mcqMarks = safe_stoi(parts[5]);
            r.paragraphMarks = safe_stoi(parts[6]);
            
            int ansCount = safe_stoi(parts[7]);
            for (int i = 0; i < ansCount && (8 + i) < parts.size(); ++i) {
                r.paragraphAnswers.push_back(unescapeJson(parts[8 + i]));
            }
            
            r.examinerId = (parts.size() > 8 + ansCount) ? parts[8 + ansCount] : exId;
            nd.results.push_back(r);
        }
    }
    f.close();
    
    examinerDataList.push_back(nd);
}

void saveExaminersList() {
    ofstream f("examiners_list.txt");
    if (!f) return;
    
    for (const auto& e : examiners) {
        f << e.id << "|" << e.name << "|" << e.email << "|" << e.password << "|"
          << (e.active ? "1" : "0");
        for (int cat : e.allowedCategories) {
            f << "|" << cat;
        }
        f << "\n";
    }
    f.close();
}

void loadExaminersList() {
    ifstream f("examiners_list.txt");
    if (!f) return;
    
    string line;
    while (getline(f, line)) {
        stringstream ss(line);
        vector<string> parts;
        string part;
        while (getline(ss, part, '|')) parts.push_back(part);
        
        if (parts.size() < 5) continue;
        
        Examiner e;
        e.id = parts[0];
        e.name = parts[1];
        e.email = parts[2];
        e.password = parts[3];
        e.active = (parts[4] == "1");
        
        for (size_t i = 5; i < parts.size(); ++i) {
            e.allowedCategories.push_back(safe_stoi(parts[i]));
        }
        
        examiners.push_back(e);
        loadExaminerData(e.id);
    }
    f.close();
}

Examiner* getExaminerById(const string& id) {
    for (auto& ex : examiners) {
        if (ex.id == id) return &ex;
    }
    return nullptr;
}

Examiner* getExaminerByEmail(const string& email) {
    for (auto& ex : examiners) {
        if (ex.email == email) return &ex;
    }
    return nullptr;
}

void loadDefaultQuestions(int cat, vector<Question>& qs) {
    qs.clear();
    
    if (cat == 0) { // Cyber Security
        qs.push_back({0, "HTTPS uses which port?", {"80", "443", "21", "22"}, 1, 0});
        qs.push_back({0, "What is Phishing?", {"Fake email to steal data", "Fishing", "Hardware attack", "None"}, 0, 0});
        qs.push_back({1, "Explain the importance of two-factor authentication in cybersecurity.", {}, 0, 5});
        qs.push_back({0, "Which is NOT a type of malware?", {"Virus", "Trojan", "Firewall", "Spyware"}, 2, 0});
        qs.push_back({0, "What does VPN stand for?", {"Virtual Private Network", "Virtual Personal Node", "Verified Private Network", "Virtual Protocol Network"}, 0, 0});
        qs.push_back({1, "Describe the difference between encryption and hashing.", {}, 0, 5});
        qs.push_back({0, "Which protocol is used for secure web browsing?", {"HTTP", "FTP", "HTTPS", "SMTP"}, 2, 0});
        qs.push_back({0, "What is a DDoS attack?", {"Data Deletion", "Distributed Denial of Service", "Direct Disk Overwrite", "Digital Document Security"}, 1, 0});
        qs.push_back({0, "Which is a strong password practice?", {"Using birthdate", "Using pet's name", "Using special characters", "Using 'password'"}, 2, 0});
        qs.push_back({1, "What are the main principles of the CIA triad in security?", {}, 0, 5});
        qs.push_back({0, "What does SSL stand for?", {"Secure Socket Layer", "System Security Level", "Server Side Logic", "Secure System Login"}, 0, 0});
        qs.push_back({0, "Which is a social engineering attack?", {"Brute force", "SQL injection", "Phishing", "Buffer overflow"}, 2, 0});
        qs.push_back({0, "What is the purpose of a firewall?", {"To prevent physical access", "To filter network traffic", "To encrypt data", "To create backups"}, 1, 0});
        qs.push_back({1, "Explain the concept of 'defense in depth' in cybersecurity.", {}, 0, 5});
        qs.push_back({0, "Which is NOT a cyber threat?", {"Ransomware", "Adware", "Open source software", "Spyware"}, 2, 0});
        qs.push_back({0, "What is multi-factor authentication?", {"Using multiple passwords", "Using biometrics plus password", "Using same password everywhere", "Using no password"}, 1, 0});
        qs.push_back({0, "Which law protects digital privacy in many countries?", {"GDPR", "HTTP", "TCP/IP", "ISO"}, 0, 0});
        qs.push_back({1, "Describe how a man-in-the-middle attack works.", {}, 0, 5});
        qs.push_back({0, "What is patch management?", {"Managing sewing patches", "Updating software regularly", "Managing employee patches", "Creating security patches"}, 1, 0});
        qs.push_back({0, "Which is a physical security measure?", {"Firewall", "Antivirus", "Security cameras", "Encryption"}, 2, 0});
    }
    else if (cat == 1) { // Artificial Intelligence
        qs.push_back({0, "Who is considered the father of AI?", {"Alan Turing", "John McCarthy", "Marvin Minsky", "Herbert Simon"}, 1, 0});
        qs.push_back({0, "Which are types of machine learning?", {"Supervised", "Unsupervised", "Reinforcement", "All of these"}, 3, 0});
        qs.push_back({1, "Explain the difference between AI, ML, and Deep Learning.", {}, 0, 5});
        qs.push_back({0, "What is neural network inspired by?", {"Computer circuits", "Human brain", "Mathematics", "Physics"}, 1, 0});
        qs.push_back({0, "Which is NOT an AI application?", {"Self-driving cars", "Spam filters", "Spreadsheets", "Chatbots"}, 2, 0});
        qs.push_back({1, "Describe how a recommendation system works.", {}, 0, 5});
        qs.push_back({0, "What does NLP stand for?", {"Natural Language Processing", "Neural Learning Process", "Network Layer Protocol", "National Library Program"}, 0, 0});
        qs.push_back({0, "What is overfitting in ML?", {"Model too simple", "Model too complex", "Too little data", "Too many features"}, 1, 0});
        qs.push_back({0, "Which algorithm is used for classification?", {"K-Means", "Linear Regression", "Decision Tree", "Apriori"}, 2, 0});
        qs.push_back({1, "Explain the concept of 'training data' vs 'testing data'.", {}, 0, 5});
        qs.push_back({0, "What is deep learning?", {"AI with many layers", "Simple algorithms", "Rule-based systems", "Statistical analysis"}, 0, 0});
        qs.push_back({0, "Which is a supervised learning problem?", {"Clustering", "Dimensionality reduction", "Regression", "Association"}, 2, 0});
        qs.push_back({0, "What does CNN stand for in AI?", {"Central Neural Network", "Convolutional Neural Network", "Cognitive Neural Network", "Complex Neural Network"}, 1, 0});
        qs.push_back({1, "What are the ethical concerns in AI development?", {}, 0, 5});
        qs.push_back({0, "What is reinforcement learning?", {"Learning from labeled data", "Learning from unlabeled data", "Learning from rewards", "Learning from rules"}, 2, 0});
        qs.push_back({0, "Which is NOT a Python ML library?", {"TensorFlow", "PyTorch", "Scikit-learn", "JavaML"}, 3, 0});
        qs.push_back({0, "What is computer vision?", {"Making computers see", "Creating visual art", "Designing UI", "Writing code visually"}, 0, 0});
        qs.push_back({1, "Describe the Turing Test and its significance.", {}, 0, 5});
        qs.push_back({0, "What is transfer learning?", {"Transferring money", "Reusing pre-trained models", "Moving data", "Changing algorithms"}, 1, 0});
        qs.push_back({0, "Which is an AI ethics principle?", {"Maximize profit only", "Transparency and fairness", "Secrecy", "Complexity"}, 1, 0});
    }
    else if (cat == 2) { // Graphic Designing
        qs.push_back({0, "What does RGB stand for?", {"Red Green Blue", "Royal Graphics Basic", "Raster Graphics Bit", "Rapid Graphic Build"}, 0, 0});
        qs.push_back({0, "Which is NOT a graphic design software?", {"Adobe Photoshop", "Microsoft Word", "Adobe Illustrator", "CorelDRAW"}, 1, 0});
        qs.push_back({1, "Explain the importance of color theory in graphic design.", {}, 0, 5});
        qs.push_back({0, "What is kerning in typography?", {"Letter spacing", "Line spacing", "Font size", "Font weight"}, 0, 0});
        qs.push_back({0, "Which color model is used for print?", {"RGB", "CMYK", "HSV", "HEX"}, 1, 0});
        qs.push_back({1, "Describe the difference between vector and raster graphics.", {}, 0, 5});
        qs.push_back({0, "What is the rule of thirds in design?", {"Dividing image into 9 parts", "Using only 3 colors", "3D design principle", "File format type"}, 0, 0});
        qs.push_back({0, "Which file format supports transparency?", {"JPG", "BMP", "PNG", "TIFF"}, 2, 0});
        qs.push_back({0, "What is a mood board used for?", {"Collecting design inspiration", "Measuring colors", "Coding interface", "Printing designs"}, 0, 0});
        qs.push_back({1, "Explain the concept of visual hierarchy in design.", {}, 0, 5});
        qs.push_back({0, "What does DPI stand for?", {"Dots Per Inch", "Design Process Interface", "Digital Print Index", "Document Page Info"}, 0, 0});
        qs.push_back({0, "Which is a vector file format?", {"JPG", "PNG", "SVG", "BMP"}, 2, 0});
        qs.push_back({0, "What is negative space in design?", {"Empty space around elements", "Dark colors", "Error in design", "Background image"}, 0, 0});
        qs.push_back({1, "Describe the role of typography in creating brand identity.", {}, 0, 5});
        qs.push_back({0, "Which tool is used for color selection harmony?", {"Color wheel", "Ruler", "Eraser", "Blur tool"}, 0, 0});
        qs.push_back({0, "What is a mockup in design?", {"Real product display", "Sketch of idea", "Color palette", "Font collection"}, 0, 0});
        qs.push_back({0, "Which software is best for logo design?", {"Photoshop", "Illustrator", "Excel", "Word"}, 1, 0});
        qs.push_back({1, "Explain the importance of consistency in UI/UX design.", {}, 0, 5});
        qs.push_back({0, "What is bleed in print design?", {"Extra area for trimming", "Color bleeding", "Paper type", "Ink type"}, 0, 0});
        qs.push_back({0, "Which is a design principle?", {"Contrast", "Programming", "Accounting", "Cooking"}, 0, 0});
    }
    else if (cat == 3) { // Data Science
        qs.push_back({0, "What is data science?", {"Study of data", "Programming only", "Database management", "Hardware design"}, 0, 0});
        qs.push_back({0, "Which language is most used in data science?", {"Java", "Python", "C++", "HTML"}, 1, 0});
        qs.push_back({1, "Explain the data science lifecycle.", {}, 0, 5});
        qs.push_back({0, "What is pandas in Python?", {"Animal library", "Data manipulation library", "Game library", "Graphics library"}, 1, 0});
        qs.push_back({0, "Which is NOT a data visualization tool?", {"Matplotlib", "Seaborn", "Tableau", "MySQL"}, 3, 0});
        qs.push_back({1, "Describe the difference between supervised and unsupervised learning.", {}, 0, 5});
        qs.push_back({0, "What does SQL stand for?", {"Structured Query Language", "Simple Question Language", "System Quality Logic", "Standard Query Logic"}, 0, 0});
        qs.push_back({0, "What is correlation in statistics?", {"Relationship between variables", "Data cleaning", "Data storage", "Algorithm type"}, 0, 0});
        qs.push_back({0, "Which is used for big data processing?", {"Excel", "Hadoop", "Word", "PowerPoint"}, 1, 0});
        qs.push_back({1, "Explain the concept of feature engineering.", {}, 0, 5});
        qs.push_back({0, "What is the purpose of EDA?", {"Exploratory Data Analysis", "Error Detection Algorithm", "Electronic Design Automation", "Event Driven Architecture"}, 0, 0});
        qs.push_back({0, "Which algorithm is used for clustering?", {"Linear Regression", "Decision Tree", "K-Means", "Logistic Regression"}, 2, 0});
        qs.push_back({0, "What is overfitting?", {"Model performs well on training but not testing", "Model too simple", "Too much data", "Fast training"}, 0, 0});
        qs.push_back({1, "Describe the bias-variance tradeoff in machine learning.", {}, 0, 5});
        qs.push_back({0, "What is a DataFrame?", {"2D labeled data structure", "3D model", "Database server", "File format"}, 0, 0});
        qs.push_back({0, "Which is a data preprocessing technique?", {"Normalization", "Programming", "Designing", "Marketing"}, 0, 0});
        qs.push_back({0, "What is the purpose of cross-validation?", {"Assess model performance", "Clean data", "Store data", "Visualize data"}, 0, 0});
        qs.push_back({1, "Explain the importance of data cleaning in data science.", {}, 0, 5});
        qs.push_back({0, "What is outlier detection?", {"Finding unusual data points", "Creating reports", "Writing code", "Designing UI"}, 0, 0});
        qs.push_back({0, "Which tool is used for version control in data science?", {"Git", "Excel", "Photoshop", "Word"}, 0, 0});
    }
    else if (cat == 4) { // Web Development
        qs.push_back({0, "What does HTML stand for?", {"Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Markup Language", "Home Tool Markup Language"}, 0, 0});
        qs.push_back({0, "Which is NOT a frontend technology?", {"HTML", "CSS", "JavaScript", "MySQL"}, 3, 0});
        qs.push_back({1, "Explain the difference between frontend and backend development.", {}, 0, 5});
        qs.push_back({0, "What is CSS used for?", {"Styling web pages", "Database queries", "Server logic", "Data analysis"}, 0, 0});
        qs.push_back({0, "Which is a JavaScript framework?", {"Django", "Laravel", "React", "Spring"}, 2, 0});
        qs.push_back({1, "Describe how HTTP requests work in web development.", {}, 0, 5});
        qs.push_back({0, "What is responsive web design?", {"Design that works on all devices", "Fast loading design", "Colorful design", "3D design"}, 0, 0});
        qs.push_back({0, "Which is a backend programming language?", {"HTML", "CSS", "Python", "JavaScript (frontend)"}, 2, 0});
        qs.push_back({0, "What is an API?", {"Application Programming Interface", "Advanced Programming Interface", "Application Process Interface", "Automated Programming Interface"}, 0, 0});
        qs.push_back({1, "Explain the role of databases in web applications.", {}, 0, 5});
        qs.push_back({0, "What is Git used for?", {"Version control", "Web hosting", "Database management", "Graphic design"}, 0, 0});
        qs.push_back({0, "Which is a NoSQL database?", {"MySQL", "PostgreSQL", "MongoDB", "Oracle"}, 2, 0});
        qs.push_back({0, "What is DOM?", {"Document Object Model", "Data Object Model", "Document Online Model", "Digital Object Management"}, 0, 0});
        qs.push_back({1, "Describe the importance of web security measures.", {}, 0, 5});
        qs.push_back({0, "What is a CDN?", {"Content Delivery Network", "Code Development Network", "Computer Data Network", "Central Digital Network"}, 0, 0});
        qs.push_back({0, "Which method is used for form submission?", {"GET", "POST", "Both", "None"}, 2, 0});
        qs.push_back({0, "What is AJAX?", {"Asynchronous JavaScript and XML", "Advanced Java and XML", "Automated JavaScript XML", "Asynchronous Java XML"}, 0, 0});
        qs.push_back({1, "Explain the concept of RESTful APIs.", {}, 0, 5});
        qs.push_back({0, "What is npm?", {"Node Package Manager", "New Project Manager", "Network Protocol Manager", "Node Process Manager"}, 0, 0});
        qs.push_back({0, "Which is used for real-time web applications?", {"WebSocket", "FTP", "SMTP", "HTTP only"}, 0, 0});
    }
    else if (cat == 5) { // Software Engineering
        qs.push_back({0, "What is SDLC?", {"Software Development Life Cycle", "System Design Logic Cycle", "Software Data Life Cycle", "System Development Logic Code"}, 0, 0});
        qs.push_back({0, "Which is NOT a programming paradigm?", {"Object-Oriented", "Functional", "Procedural", "Cooking"}, 3, 0});
        qs.push_back({1, "Explain the Agile methodology in software development.", {}, 0, 5});
        qs.push_back({0, "What is version control?", {"Tracking code changes", "Writing code", "Testing code", "Deploying code"}, 0, 0});
        qs.push_back({0, "Which is a testing type?", {"Unit Testing", "Cooking Test", "Sleep Test", "Color Test"}, 0, 0});
        qs.push_back({1, "Describe the difference between waterfall and agile methodologies.", {}, 0, 5});
        qs.push_back({0, "What is refactoring?", {"Improving code without changing behavior", "Writing new code", "Testing code", "Documenting code"}, 0, 0});
        qs.push_back({0, "Which is a design pattern?", {"Singleton", "For loop", "Variable", "Function"}, 0, 0});
        qs.push_back({0, "What is CI/CD?", {"Continuous Integration/Continuous Deployment", "Code Interface/Code Design", "Computer Input/Computer Display", "Coding Interface/Coding Database"}, 0, 0});
        qs.push_back({1, "Explain the importance of code reviews in software engineering.", {}, 0, 5});
        qs.push_back({0, "What is UML?", {"Unified Modeling Language", "Universal Machine Language", "User Management Logic", "Unified Memory Language"}, 0, 0});
        qs.push_back({0, "Which is NOT a software development model?", {"Waterfall", "Agile", "Spiral", "Circle"}, 3, 0});
        qs.push_back({0, "What is pair programming?", {"Two programmers working together", "Writing parallel code", "Testing in pairs", "Deploying in pairs"}, 0, 0});
        qs.push_back({1, "Describe the concept of technical debt.", {}, 0, 5});
        qs.push_back({0, "What is debugging?", {"Finding and fixing errors", "Writing documentation", "Creating UI", "Database design"}, 0, 0});
        qs.push_back({0, "Which is a software architecture pattern?", {"MVC", "ABC", "XYZ", "123"}, 0, 0});
        qs.push_back({0, "What is scalability?", {"Ability to handle growth", "Code readability", "Testing coverage", "Documentation quality"}, 0, 0});
        qs.push_back({1, "Explain the role of documentation in software projects.", {}, 0, 5});
        qs.push_back({0, "What is a software requirement?", {"What the software should do", "Programming language", "Database type", "UI design"}, 0, 0});
        qs.push_back({0, "Which is a risk in software projects?", {"Scope creep", "Good planning", "Clear requirements", "Experienced team"}, 0, 0});
    }
    else {
        // Fallback for any other category
        for (int i = 1; i <= 10; i++) {
            Question q;
            q.type = (i % 3 == 0) ? 1 : 0;
            q.text = "Sample question " + to_string(i) + " for category " + to_string(cat);
            if (q.type == 0) {
                q.opt[0] = "Option A";
                q.opt[1] = "Option B";
                q.opt[2] = "Option C";
                q.opt[3] = "Option D";
                q.correct = i % 4;
            }
            q.durationMinutes = (q.type == 1) ? 5 : 0;
            qs.push_back(q);
        }
    }
}

// ===================== API ENDPOINTS =====================
string handleRequest(const string& request) {
    stringstream ss(request);
    string method, path, version;
    ss >> method >> path >> version;
    
    // Handle favicon
    if (path == "/favicon.ico") return httpResponse(204, "");
    
    // Serve static files
    if (path == "/" || path == "/index.html") {
        ifstream f("index.html");
        if (f) {
            string html((istreambuf_iterator<char>(f)), {});
            return httpResponse(200, html, "text/html");
        }
        return httpResponse(404, "{\"error\":\"index.html not found\"}");
    }
    if (path == "/style.css") {
        ifstream f("style.css");
        if (f) {
            string css((istreambuf_iterator<char>(f)), {});
            return httpResponse(200, css, "text/css");
        }
    }
    if (path == "/script.js") {
        ifstream f("script.js");
        if (f) {
            string js((istreambuf_iterator<char>(f)), {});
            return httpResponse(200, js, "application/javascript");
        }
    }
    
    // Get body
    size_t pos = request.find("\r\n\r\n");
    string body = (pos != string::npos) ? request.substr(pos + 4) : "";
    map<string, string> params = parseSimpleJson(body);
    
    // === HEAD ADMIN ENDPOINTS ===
    if (path == "/api/head-admin-login") {
        if (params["email"] == HEAD_EMAIL && params["password"] == HEAD_PASS) {
            return httpResponse(200, "{\"success\":true}");
        }
        return httpResponse(200, "{\"success\":false,\"error\":\"Invalid credentials\"}");
    }
    
    if (path == "/api/categories") {
        stringstream json;
        json << "{\"categories\":[";
        for (size_t i = 0; i < categories.size(); ++i) {
            json << "\"" << escapeJson(categories[i]) << "\"";
            if (i < categories.size() - 1) json << ",";
        }
        json << "]}";
        return httpResponse(200, json.str());
    }
    
    if (path == "/api/add-category" && method == "POST") {
        if (params["name"].empty()) return httpResponse(400, "{\"error\":\"Category name required\"}");
        categories.push_back(params["name"]);
        saveCategories();
        return httpResponse(200, "{\"success\":true}");
    }
    
    // === EXAMINER ENDPOINTS ===
    if (path == "/api/examiner-login") {
        string email = params["email"];
        string password = params["password"];
        string examinerId = params["examinerId"];
        
        for (const auto& ex : examiners) {
            if (ex.email == email && ex.password == password && ex.id == examinerId && ex.active) {
                stringstream json;
                json << "{\"success\":true,\"examiner\":{";
                json << "\"id\":\"" << ex.id << "\",";
                json << "\"name\":\"" << escapeJson(ex.name) << "\",";
                json << "\"allowedCategories\":[";
                for (size_t i = 0; i < ex.allowedCategories.size(); ++i) {
                    json << ex.allowedCategories[i];
                    if (i < ex.allowedCategories.size() - 1) json << ",";
                }
                json << "]";
                json << "}}";
                return httpResponse(200, json.str());
            }
        }
        return httpResponse(200, "{\"success\":false,\"error\":\"Invalid login\"}");
    }
    
    if (path == "/api/examiners" && method == "GET") {
        stringstream json;
        json << "{\"examiners\":[";
        for (size_t i = 0; i < examiners.size(); ++i) {
            const auto& ex = examiners[i];
            json << "{";
            json << "\"id\":\"" << ex.id << "\",";
            json << "\"name\":\"" << escapeJson(ex.name) << "\",";
            json << "\"email\":\"" << escapeJson(ex.email) << "\",";
            json << "\"active\":" << (ex.active ? "true" : "false") << ",";
            json << "\"allowedCategories\":[";
            for (size_t j = 0; j < ex.allowedCategories.size(); ++j) {
                json << ex.allowedCategories[j];
                if (j < ex.allowedCategories.size() - 1) json << ",";
            }
            json << "]";
            json << "}";
            if (i < examiners.size() - 1) json << ",";
        }
        json << "]}";
        return httpResponse(200, json.str());
    }
    
    if (path == "/api/add-examiner" && method == "POST") {
        Examiner ne;
        ne.name = params["name"];
        ne.email = params["email"];
        ne.password = params["password"];
        ne.id = generateExaminerID();
        ne.active = true;
        
        // Parse allowed categories
        string cats = params["allowedCategories"];
        stringstream ss(cats);
        string cat;
        while (getline(ss, cat, ',')) {
            int catNum = safe_stoi(cat, -1);
            if (catNum >= 0 && catNum < (int)categories.size()) {
                ne.allowedCategories.push_back(catNum);
            }
        }
        
        examiners.push_back(ne);
        
        ExaminerData nd;
        nd.examinerId = ne.id;
        examinerDataList.push_back(nd);
        
        saveExaminersList();
        
        stringstream json;
        json << "{\"success\":true,\"examiner\":{";
        json << "\"id\":\"" << ne.id << "\",";
        json << "\"name\":\"" << escapeJson(ne.name) << "\"";
        json << "}}";
        return httpResponse(200, json.str());
    }
    
    // === STUDENT ENDPOINTS ===
    if (path == "/api/student-login") {
        string id = params["id"];
        
        cout << "DEBUG: Student login attempt with ID: " << id << endl;
        
        for (auto& data : examinerDataList) {
            for (auto& s : data.students) {
                cout << "DEBUG: Checking student " << s.name << " IDs: " << s.id1 << ", " << s.id2 << endl;
                if ((s.id1 == id && !s.used1) || (s.id2 == id && !s.used2)) {
                    cout << "DEBUG: Found student " << s.name << " in examiner " << data.examinerId << endl;
                    
                    if (s.id1 == id) s.used1 = true;
                    else s.used2 = true;
                    
                    activeExams.push_back(id);
                    examTimers[id] = time(0) + 40 * 60; // 40 minutes
                    
                    saveExaminerData(data.examinerId);
                    
                    stringstream json;
                    json << "{\"success\":true,\"student\":{";
                    json << "\"name\":\"" << escapeJson(s.name) << "\",";
                    json << "\"category\":\"" << escapeJson(categories[s.category]) << "\",";
                    json << "\"categoryIndex\":" << s.category << ",";
                    json << "\"examinerId\":\"" << s.examinerId << "\"";
                    json << "}}";
                    return httpResponse(200, json.str());
                }
            }
        }
        cout << "DEBUG: Student ID not found or already used: " << id << endl;
        return httpResponse(200, "{\"success\":false,\"error\":\"Invalid or used ID\"}");
    }
    
    if (path == "/api/examiner-students") {
        string examinerId = params["examinerId"];
        ExaminerData* data = findExaminerData(examinerId);
        if (!data) return httpResponse(404, "{\"error\":\"Examiner not found\"}");
        
        stringstream json;
        json << "{\"students\":[";
        for (size_t i = 0; i < data->students.size(); ++i) {
            const auto& s = data->students[i];
            json << "{";
            json << "\"name\":\"" << escapeJson(s.name) << "\",";
            json << "\"email\":\"" << escapeJson(s.email) << "\",";
            json << "\"category\":\"" << escapeJson(categories[s.category]) << "\",";
            json << "\"id1\":\"" << s.id1 << "\",";
            json << "\"id2\":\"" << s.id2 << "\",";
            json << "\"used1\":" << (s.used1 ? "true" : "false") << ",";
            json << "\"used2\":" << (s.used2 ? "true" : "false");
            json << "}";
            if (i < data->students.size() - 1) json << ",";
        }
        json << "]}";
        return httpResponse(200, json.str());
    }
    
    if (path == "/api/add-student" && method == "POST") {
        string examinerId = params["examinerId"];
        ExaminerData* data = findExaminerData(examinerId);
        if (!data) return httpResponse(404, "{\"error\":\"Examiner not found\"}");
        
        Student s;
        s.name = params["name"];
        s.email = params["email"];
        s.category = safe_stoi(params["category"]);
        s.examinerId = examinerId;
        s.id1 = generateID();
        s.id2 = generateID();
        
        data->students.push_back(s);
        saveExaminerData(examinerId);
        
        stringstream json;
        json << "{\"success\":true,\"student\":{";
        json << "\"name\":\"" << escapeJson(s.name) << "\",";
        json << "\"id1\":\"" << s.id1 << "\",";
        json << "\"id2\":\"" << s.id2 << "\"";
        json << "}}";
        return httpResponse(200, json.str());
    }
    
    // === QUESTION ENDPOINTS ===
    if (path == "/api/examiner-questions") {
        string examinerId = params["examinerId"];
        int category = safe_stoi(params["category"]);
        ExaminerData* data = findExaminerData(examinerId);
        if (!data || category < 0 || category >= 6) {
            return httpResponse(400, "{\"error\":\"Invalid parameters\"}");
        }
        
        stringstream json;
        json << "{\"questions\":[";
        const auto& qs = data->questionsPerCategory[category];
        for (size_t i = 0; i < qs.size(); ++i) {
            const auto& q = qs[i];
            json << "{";
            json << "\"type\":" << q.type << ",";
            json << "\"text\":\"" << escapeJson(q.text) << "\",";
            if (q.type == 0) {
                json << "\"options\":[";
                for (int j = 0; j < 4; ++j) {
                    json << "\"" << escapeJson(q.opt[j]) << "\"";
                    if (j < 3) json << ",";
                }
                json << "],";
                json << "\"correct\":" << q.correct << ",";
            }
            json << "\"durationMinutes\":" << q.durationMinutes;
            json << "}";
            if (i < qs.size() - 1) json << ",";
        }
        json << "],\"duration\":" << data->settingsPerCategory[category].duration << "}";
        return httpResponse(200, json.str());
    }
    
    if (path == "/api/add-question" && method == "POST") {
        string examinerId = params["examinerId"];
        int category = safe_stoi(params["category"]);
        ExaminerData* data = findExaminerData(examinerId);
        if (!data || category < 0 || category >= 6) {
            return httpResponse(400, "{\"error\":\"Invalid parameters\"}");
        }
        
        Question q;
        q.type = safe_stoi(params["type"]);
        q.text = params["text"];
        
        if (q.type == 0) {
            for (int i = 0; i < 4; ++i) {
                q.opt[i] = params["options[" + to_string(i) + "]"];
            }
            q.correct = safe_stoi(params["correct"]);
        }
        q.durationMinutes = safe_stoi(params["durationMinutes"]);
        
        data->questionsPerCategory[category].push_back(q);
        saveExaminerData(examinerId);
        
        return httpResponse(200, "{\"success\":true}");
    }
    
    if (path == "/api/load-default-questions" && method == "POST") {
        string examinerId = params["examinerId"];
        int category = safe_stoi(params["category"]);
        ExaminerData* data = findExaminerData(examinerId);
        if (!data || category < 0 || category >= 6) {
            return httpResponse(400, "{\"error\":\"Invalid parameters\"}");
        }
        
        loadDefaultQuestions(category, data->questionsPerCategory[category]);
        saveExaminerData(examinerId);
        
        return httpResponse(200, "{\"success\":true}");
    }
    
    if (path == "/api/set-duration" && method == "POST") {
        string examinerId = params["examinerId"];
        int category = safe_stoi(params["category"]);
        int duration = safe_stoi(params["duration"]);
        ExaminerData* data = findExaminerData(examinerId);
        if (!data || category < 0 || category >= 6 || duration <= 0) {
            return httpResponse(400, "{\"error\":\"Invalid parameters\"}");
        }
        
        data->settingsPerCategory[category].duration = duration;
        saveExaminerData(examinerId);
        
        return httpResponse(200, "{\"success\":true}");
    }
    
    // === EXAM ENDPOINTS ===
    if (path == "/api/get-exam-questions") {
        string studentId = params["studentId"];
        
        cout << "DEBUG: Getting exam questions for student: " << studentId << endl;
        
        if (studentId.empty()) {
            return httpResponse(400, "{\"error\":\"Student ID required\"}");
        }
        
        // Find student
        Student* student = nullptr;
        ExaminerData* data = nullptr;
        int foundCategory = -1;
        
        for (auto& ed : examinerDataList) {
            for (auto& s : ed.students) {
                cout << "DEBUG: Checking student " << s.id1 << " and " << s.id2 << endl;
                if (s.id1 == studentId || s.id2 == studentId) {
                    student = &s;
                    data = &ed;
                    foundCategory = s.category;
                    cout << "DEBUG: Found student in examiner " << ed.examinerId 
                         << " category: " << foundCategory << endl;
                    break;
                }
            }
            if (student) break;
        }
        
        if (!student || !data) {
            cout << "DEBUG: Student not found for ID: " << studentId << endl;
            return httpResponse(404, "{\"error\":\"Student not found\"}");
        }
        
        if (foundCategory < 0 || foundCategory >= 6) {
            cout << "DEBUG: Invalid category: " << foundCategory << endl;
            return httpResponse(400, "{\"error\":\"Invalid category\"}");
        }
        
        // Check if questions exist
        auto& qs = data->questionsPerCategory[foundCategory];
        int duration = data->settingsPerCategory[foundCategory].duration;
        
        cout << "DEBUG: Found " << qs.size() << " questions for category " 
             << foundCategory << " (duration: " << duration << ")" << endl;
        
        // If no questions, load default ones automatically
        if (qs.empty()) {
            cout << "DEBUG: No questions found, loading defaults..." << endl;
            loadDefaultQuestions(foundCategory, qs);
            saveExaminerData(data->examinerId);
            cout << "DEBUG: Default questions loaded: " << qs.size() << " questions" << endl;
        }
        
        // Build response
        stringstream json;
        json << "{\"questions\":[";
        
        for (size_t i = 0; i < qs.size(); ++i) {
            const auto& q = qs[i];
            json << "{";
            json << "\"type\":" << q.type << ",";
            json << "\"text\":\"" << escapeJson(q.text) << "\"";
            
            if (q.type == 0) {
                json << ",\"options\":[";
                for (int j = 0; j < 4; ++j) {
                    json << "\"" << escapeJson(q.opt[j]) << "\"";
                    if (j < 3) json << ",";
                }
                json << "]";
                json << ",\"correct\":" << q.correct;
            }
            
            json << ",\"durationMinutes\":" << q.durationMinutes;
            json << "}";
            
            if (i < qs.size() - 1) json << ",";
        }
        
        json << "],\"duration\":" << duration << "}";
        
        cout << "DEBUG: Sending response with " << qs.size() << " questions" << endl;
        return httpResponse(200, json.str());
    }

    // Add after the existing results endpoints

// Get paragraph answers for evaluation
if (path == "/api/get-paragraph-answers") {
    string examinerId = params["examinerId"];
    string studentId = params["studentId"];
    
    ExaminerData* data = findExaminerData(examinerId);
    if (!data) return httpResponse(404, "{\"error\":\"Examiner not found\"}");
    
    // Find the result for this student
    Result* result = nullptr;
    for (auto& r : data->results) {
        if (r.id == studentId) {
            result = &r;
            break;
        }
    }
    
    if (!result) return httpResponse(404, "{\"error\":\"Result not found\"}");
    
    stringstream json;
    json << "{\"paragraphs\":[";
    for (size_t i = 0; i < result->paragraphAnswers.size(); ++i) {
        json << "{";
        json << "\"index\":" << i << ",";
        json << "\"answer\":\"" << escapeJson(result->paragraphAnswers[i]) << "\",";
        json << "\"marks\":" << result->paragraphMarks;
        json << "}";
        if (i < result->paragraphAnswers.size() - 1) json << ",";
    }
    json << "],";
    json << "\"studentName\":\"" << escapeJson(result->name) << "\",";
    json << "\"category\":\"" << escapeJson(categories[result->category]) << "\",";
    json << "\"mcqScore\":" << result->mcqMarks << ",";
    json << "\"totalParagraphs\":" << result->paragraphAnswers.size();
    json << "}";
    
    return httpResponse(200, json.str());
}

// Update paragraph marks
if (path == "/api/update-paragraph-marks" && method == "POST") {
    string examinerId = params["examinerId"];
    string studentId = params["studentId"];
    string marksJson = params["marks"];
    
    ExaminerData* data = findExaminerData(examinerId);
    if (!data) return httpResponse(404, "{\"error\":\"Examiner not found\"}");
    
    // Find the result
    Result* result = nullptr;
    for (auto& r : data->results) {
        if (r.id == studentId) {
            result = &r;
            break;
        }
    }
    
    if (!result) return httpResponse(404, "{\"error\":\"Result not found\"}");
    
    // Parse marks
    vector<int> paragraphMarks;
    stringstream ss(marksJson);
    string markStr;
    int totalMarks = 0;
    
    while (getline(ss, markStr, ',')) {
        int mark = safe_stoi(markStr, 0);
        paragraphMarks.push_back(mark);
        totalMarks += mark;
    }
    
    // Update result
    result->paragraphMarks = totalMarks;
    
    saveExaminerData(examinerId);
    
    stringstream json;
    json << "{\"success\":true,\"totalMarks\":" << totalMarks << "}";
    return httpResponse(200, json.str());
}

// Get students with paragraph answers pending evaluation
if (path == "/api/pending-evaluations") {
    string examinerId = params["examinerId"];
    ExaminerData* data = findExaminerData(examinerId);
    if (!data) return httpResponse(404, "{\"error\":\"Examiner not found\"}");
    
    stringstream json;
    json << "{\"students\":[";
    
    bool first = true;
    for (const auto& r : data->results) {
        if (r.paragraphAnswers.size() > 0) {
            if (!first) json << ",";
            first = false;
            
            json << "{";
            json << "\"id\":\"" << r.id << "\",";
            json << "\"name\":\"" << escapeJson(r.name) << "\",";
            json << "\"category\":\"" << escapeJson(categories[r.category]) << "\",";
            json << "\"mcqScore\":" << r.mcqMarks << ",";
            json << "\"paragraphMarks\":" << r.paragraphMarks << ",";
            json << "\"paragraphCount\":" << r.paragraphAnswers.size() << ",";
            json << "\"date\":\"" << escapeJson(r.date) << "\",";
            json << "\"evaluated\":" << (r.paragraphMarks > 0 ? "true" : "false");
            json << "}";
        }
    }
    json << "]}";
    
    return httpResponse(200, json.str());
}
    
    if (path == "/api/submit-exam" && method == "POST") {
        string studentId = params["studentId"];
        string answersJson = params["answers"];
        string paragraphAnswersJson = params["paragraphAnswers"];
        
        cout << "DEBUG: Submitting exam for student: " << studentId << endl;
        
        // Find student
        Student* student = nullptr;
        ExaminerData* data = nullptr;
        for (auto& ed : examinerDataList) {
            for (auto& s : ed.students) {
                if (s.id1 == studentId || s.id2 == studentId) {
                    student = &s;
                    data = &ed;
                    break;
                }
            }
            if (student) break;
        }
        
        if (!student || !data) return httpResponse(404, "{\"error\":\"Student not found\"}");
        
        // Calculate score
        const auto& qs = data->questionsPerCategory[student->category];
        int correctCount = 0;
        int mcqCount = 0;
        
        // Parse MCQ answers
        map<int, int> mcqAnswers;
        if (!answersJson.empty()) {
            stringstream ss(answersJson);
            string pair;
            while (getline(ss, pair, ';')) {
                size_t colon = pair.find(':');
                if (colon != string::npos) {
                    int qIndex = safe_stoi(pair.substr(0, colon));
                    int answer = safe_stoi(pair.substr(colon + 1));
                    mcqAnswers[qIndex] = answer;
                }
            }
        }
        
        // Calculate MCQ score
        for (size_t i = 0; i < qs.size(); ++i) {
            if (qs[i].type == 0) {
                mcqCount++;
                if (mcqAnswers.find(i) != mcqAnswers.end() && mcqAnswers[i] == qs[i].correct) {
                    correctCount++;
                }
            }
        }
        
        int mcqPercent = (mcqCount > 0) ? (correctCount * 100) / mcqCount : 0;
        
        // Parse paragraph answers
        vector<string> paragraphAnswers;
        if (!paragraphAnswersJson.empty()) {
            stringstream ss(paragraphAnswersJson);
            string answer;
            while (getline(ss, answer, '|')) {
                paragraphAnswers.push_back(unescapeJson(answer));
            }
        }
        
        // Save result
        Result r;
        r.name = student->name;
        r.email = student->email;
        r.id = studentId;
        r.date = currentTime();
        r.category = student->category;
        r.mcqMarks = mcqPercent;
        r.paragraphMarks = 0; // To be graded by examiner
        r.paragraphAnswers = paragraphAnswers;
        r.examinerId = data->examinerId;
        
        data->results.push_back(r);
        saveExaminerData(data->examinerId);
        
        // Remove from active exams
        auto it = find(activeExams.begin(), activeExams.end(), studentId);
        if (it != activeExams.end()) activeExams.erase(it);
        examTimers.erase(studentId);
        
        stringstream json;
        json << "{\"success\":true,\"result\":{";
        json << "\"mcqScore\":" << mcqPercent << ",";
        json << "\"totalQuestions\":" << qs.size() << ",";
        json << "\"mcqCorrect\":" << correctCount << ",";
        json << "\"mcqTotal\":" << mcqCount << ",";
        json << "\"paragraphCount\":" << paragraphAnswers.size();
        json << "}}";
        return httpResponse(200, json.str());
    }
    
    // === RESULTS ENDPOINTS ===
    if (path == "/api/examiner-results") {
        string examinerId = params["examinerId"];
        ExaminerData* data = findExaminerData(examinerId);
        if (!data) return httpResponse(404, "{\"error\":\"Examiner not found\"}");
        
        stringstream json;
        json << "{\"results\":[";
        for (size_t i = 0; i < data->results.size(); ++i) {
            const auto& r = data->results[i];
            json << "{";
            json << "\"name\":\"" << escapeJson(r.name) << "\",";
            json << "\"email\":\"" << escapeJson(r.email) << "\",";
            json << "\"id\":\"" << r.id << "\",";
            json << "\"category\":\"" << escapeJson(categories[r.category]) << "\",";
            json << "\"date\":\"" << escapeJson(r.date) << "\",";
            json << "\"mcqMarks\":" << r.mcqMarks << ",";
            json << "\"paragraphMarks\":" << r.paragraphMarks << ",";
            json << "\"paragraphCount\":" << r.paragraphAnswers.size();
            json << "}";
            if (i < data->results.size() - 1) json << ",";
        }
        json << "]}";
        return httpResponse(200, json.str());
    }
    
    if (path == "/api/all-results" && method == "GET") {
        stringstream json;
        json << "{\"results\":[";
        bool first = true;
        for (const auto& data : examinerDataList) {
            Examiner* ex = getExaminerById(data.examinerId);
            string examinerName = ex ? ex->name : "Unknown";
            
            for (const auto& r : data.results) {
                if (!first) json << ",";
                first = false;
                
                json << "{";
                json << "\"examiner\":\"" << escapeJson(examinerName) << "\",";
                json << "\"name\":\"" << escapeJson(r.name) << "\",";
                json << "\"email\":\"" << escapeJson(r.email) << "\",";
                json << "\"category\":\"" << escapeJson(categories[r.category]) << "\",";
                json << "\"mcqMarks\":" << r.mcqMarks << ",";
                json << "\"paragraphMarks\":" << r.paragraphMarks << ",";
                json << "\"date\":\"" << escapeJson(r.date) << "\"";
                json << "}";
            }
        }
        json << "]}";
        return httpResponse(200, json.str());
    }
    
    // === TIMER ENDPOINTS ===
    if (path == "/api/get-time") {
        string studentId = params["studentId"];
        if (examTimers.find(studentId) == examTimers.end()) {
            return httpResponse(404, "{\"error\":\"No active exam\"}");
        }
        
        time_t now = time(0);
        int left = (int)difftime(examTimers[studentId], now);
        if (left < 0) left = 0;
        
        stringstream json;
        json << "{\"timeLeft\":" << left << "}";
        return httpResponse(200, json.str());
    }
    
    // === ALERTS ===
    if (path == "/api/proctor-alert" && method == "POST") {
        string studentId = params["studentId"];
        string alertType = params["alert"];
        
        stringstream alert;
        alert << studentId << "|" << alertType << "|" << currentTime();
        alerts.push_back(alert.str());
        
        // Save alerts to file
        ofstream f("alerts.dat", ios::app);
        if (f) f << alert.str() << endl;
        f.close();
        
        return httpResponse(200, "{\"success\":true}");
    }
    
    if (path == "/api/alerts" && method == "GET") {
        stringstream json;
        json << "{\"alerts\":[";
        for (size_t i = 0; i < alerts.size(); ++i) {
            stringstream ss(alerts[i]);
            string part;
            vector<string> parts;
            while (getline(ss, part, '|')) parts.push_back(part);
            
            if (parts.size() >= 3) {
                json << "{";
                json << "\"studentId\":\"" << parts[0] << "\",";
                json << "\"type\":\"" << parts[1] << "\",";
                json << "\"time\":\"" << parts[2] << "\"";
                json << "}";
                if (i < alerts.size() - 1) json << ",";
            }
        }
        json << "]}";
        return httpResponse(200, json.str());
    }
    
    // Handle OPTIONS preflight requests
    if (method == "OPTIONS") {
        return httpResponse(200, "");
    }
    
    return httpResponse(404, "{\"error\":\"Not found\"}");
}

// ===================== MAIN SERVER =====================
int main() {
    srand(time(0));
    cout << "===========================================\n";
    cout << " CYGENTIC TEST CENTER - WEB SERVER v2.0\n";
    cout << " With Examiners, Head Admin, MCQ & Paragraph\n";
    cout << "===========================================\n\n";
    
    loadCategories();
    loadExaminersList();
    
    // If no examiners, create a default one
    if (examiners.empty()) {
        Examiner defEx;
        defEx.id = "EXM1001";
        defEx.name = "Default Examiner";
        defEx.email = "examiner@cygenic.com";
        defEx.password = "examiner123";
        defEx.active = true;
        for (int i = 0; i < 6; ++i) defEx.allowedCategories.push_back(i);
        examiners.push_back(defEx);
        
        ExaminerData nd;
        nd.examinerId = defEx.id;
        examinerDataList.push_back(nd);
        
        saveExaminersList();
        saveExaminerData(defEx.id);
        
        cout << "DEBUG: Created default examiner: EXM1001" << endl;
        cout << "DEBUG: Email: examiner@cygenic.com" << endl;
        cout << "DEBUG: Password: examiner123" << endl;
    }
    
    // Load alerts from file
    ifstream af("alerts.dat");
    if (af) {
        string line;
        while (getline(af, line)) {
            if (!line.empty()) alerts.push_back(line);
        }
    }
    af.close();
    
#ifdef _WIN32
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif
    
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        cerr << "Socket creation failed!\n";
        return 1;
    }
    
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt));
    
    sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(8080);
    
    if (bind(server_fd, (sockaddr*)&address, sizeof(address)) < 0) {
        cerr << "Bind failed!\n";
        return 1;
    }
    
    if (listen(server_fd, 10) < 0) {
        cerr << "Listen failed!\n";
        return 1;
    }
    
    cout << "Server running on: http://localhost:8080\n";
    cout << "Head Admin: " << HEAD_EMAIL << " / " << HEAD_PASS << endl;
    cout << "Default Examiner: examiner@cygenic.com / examiner123 / EXM1001" << endl;
    cout << "Press Ctrl+C to stop\n\n";
    
#ifdef _WIN32
    system("start http://localhost:8080");
#else
    system("xdg-open http://localhost:8080 || open http://localhost:8080");
#endif
    
    while (true) {
        sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        int client_fd = accept(server_fd, (sockaddr*)&client_addr, &client_len);
        if (client_fd < 0) continue;
        
        string request;
        char buffer[4096];
        int bytes;
        while ((bytes = recv(client_fd, buffer, sizeof(buffer)-1, 0)) > 0) {
            buffer[bytes] = '\0';
            request += buffer;
            if (request.find("\r\n\r\n") != string::npos) break;
        }
        
        // Log request for debugging
        cout << "DEBUG: Received request for: " << request.substr(0, 100) << endl;
        
        string response = handleRequest(request);
        send(client_fd, response.c_str(), response.length(), 0);
        close(client_fd);
    }
    
    close(server_fd);
#ifdef _WIN32
    WSACleanup();
#endif
    
    return 0;
}